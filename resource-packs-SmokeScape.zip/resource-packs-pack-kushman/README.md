#Smoke Scape

Created by Medicinal

Smoke Break!

<img src="https://puu.sh/I3aVt.png" width="765"><br/>